import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;

public class Main implements ActionListener, PropertyChangeListener
{
  public interface Support
  {
    void addActionListener(ActionListener l);
    void removeActionListener(ActionListener l);
    void fireActionEvent(String methodName,ActionEvent event);

    void addPropertyChangeListener(PropertyChangeListener l);
    void removePropertyChangeListener(PropertyChangeListener l);
    void firePropertyChangeEvent(String methodName,
      PropertyChangeEvent event);
  }

  public void actionPerformed(ActionEvent e)
  {
    System.err.println("event "+e);
  }

  public void propertyChange(PropertyChangeEvent e)
  {
    System.err.println("event "+e);
  }

  public static void main(String[] args)
  {
    GenericEventDispatcher ged=new GenericEventDispatcher();
    Support support=(Support)ged.create(Support.class,
      new Object());

    Main main=new Main();
    support.addActionListener(main);
    support.addPropertyChangeListener(main);

    support.fireActionEvent("actionPerformed",
      new ActionEvent(main,0,"go"));
    support.firePropertyChangeEvent("propertyChange",
      new PropertyChangeEvent(main,"color",null,null));

    support.removeActionListener(main);

    support.fireActionEvent("actionPerformed",
      new ActionEvent(main,0,"go"));
    support.firePropertyChangeEvent("propertyChange",
      new PropertyChangeEvent(main,"value",null,null));

    support.firePropertyChangeEvent("propertyChange",null);
    support.firePropertyChangeEvent("foo",
      new PropertyChangeEvent(main,"foo",null,null));
  }
}