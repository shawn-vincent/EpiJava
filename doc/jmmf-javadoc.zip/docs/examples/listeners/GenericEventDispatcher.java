import java.util.*;
import java.lang.reflect.*;
import javax.swing.event.EventListenerList;

import fr.umlv.jmmf.reflect.*;
import fr.umlv.jmmf.adapter.*;
import fr.umlv.jmmf.hook.*;


/** a generic event listener support.
    This class use the AdapterFactory class and MultiMethod class. 
    @author Remi Forax
    @version 2.0
 */
public class GenericEventDispatcher {
  static class MyAdapterHook extends DefaultAdapterHook {
    public void preHook(AdapterPreMessage message) {
      String name=message.getMultiMethodName();
      if (name.endsWith("Listener")) {
        if (name.startsWith("add"))
          message.setMultiMethodName("add");
        else
          message.setMultiMethodName("remove");

        // get listener class
        Class lClass=message.getParameterTypes()[0];
        message.insertParameter(0,lClass,Class.class);
      }
      else
        if (name.startsWith("fire") && name.endsWith("Event"))
          message.setMultiMethodName("fireEvent");

      super.preHook(message);
    }
  }

  public Object create(Class interfaze,Object base) {
    AdapterFactory factory=new AdapterFactory();
    factory.setHook(new MyAdapterHook());
    factory.addMultiMethod(list,mmAdd);
    factory.addMultiMethod(list,mmRemove);
    factory.addMultiMethod(this,mmFire);
    factory.addInterface(interfaze);

    return factory.create(base);
  }

  protected void fireEvent(String methodName,EventObject event)
    throws Exception {
    Class eClass=event.getClass();

    String name=eClass.getName();
    if (name.endsWith("Event"))
      name=name.substring(0,name.length()-5);
    
    Class lClass=Class.forName(name+"Listener");

    Method callback=lClass.getMethod(methodName,
      new Class[]{eClass});

    Object[] listeners=list.getListenerList();
    for (int i=listeners.length-2;i>=0;i-=2) {
      if (listeners[i]==lClass)
        callback.invoke((EventListener)listeners[i+1],
          new Object[]{event}); 
    }
  }

  private EventListenerList list=new EventListenerList();

  static {
    mmAdd=MultiMethod.create(EventListenerList.class,
      "add",2);
    mmRemove=MultiMethod.create(EventListenerList.class,
      "remove",2);
    mmFire=MultiMethod.create(GenericEventDispatcher.class,
      "fireEvent",2);
  }

  static MultiMethod mmAdd,mmRemove,mmFire;  
}
