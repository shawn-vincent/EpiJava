import java.util.*;
import fr.umlv.jmmf.reflect.*;
import fr.umlv.jmmf.adapter.*;
import fr.umlv.jmmf.hook.*;

public class DynamicMultiMethodFactory extends MultiMethodFactory
{
  public DynamicMultiMethodFactory()
  {
    super(new DefaultMultiMethodModel());
    DefaultMultiMethodModel model=(DefaultMultiMethodModel)getModel();
    model.setTypeModel(new DynamicTypeModel());
    model.setHook(new DynamicHook());

    factory=new AdapterFactory();
  }

  class DynamicTypeModel extends DefaultTypeModel
  {
    /**
     */
    public Class[] getSuperTypes(Class c)
    {
      Class[] array=super.getSuperTypes(c);
      HashSet set=(HashSet)map.get(c);
      if (set==null)
        return array;

      int slength=set.size();
      int alength=array.length;
      Class[] interfaces=new Class[slength+alength];
      set.toArray(interfaces);
      System.arraycopy(array,0,interfaces,slength,alength);
      return interfaces;
    }
  }

  class DynamicHook implements MultiMethodHook
  {
    /**
     */
    public void preHook(MultiMethodPreMessage message)
    {
      Object[] args=message.getParameters();
      Class[] types=message.getParameterTypes();

      for(int i=0;i<types.length;i++)
      {
        System.out.println("type "+types[i]);

        // wrapp
        if (factory.isWrappable(types[i]))
        {
          System.out.println("wrap");

          args[i]=factory.create(args[i]);
          continue;
        }

        // unwrapp
        /*
        HashSet set=(HashSet)map.get(types[i]);
        if (set!=null && args[i] instanceof Adapter)
          args[i]=((Adapter)args[i]).getAdaptee();
        */
      } 
    }

    public void innerHook(MultiMethodInnerMessage message) 
    { }
  
    public void postHook(MultiMethodPostMessage message) 
    { }              
  }

  public void doImplements(Class clazz,Class interfaze)
  {
    if (!(verifyImplements(clazz,interfaze)))
      throw new IllegalArgumentException(clazz+
        " don't own methods of "+interfaze);

    HashSet set=(HashSet)map.get(clazz);
    if (set==null)
    {
      set=new HashSet();
      map.put(clazz,set);
    }

    if (set.add(interfaze))
      factory.addInterface(clazz,interfaze);
    else
      return;

    HashSet iset=(HashSet)imap.get(interfaze);
    if (iset==null)
    {
      iset=new HashSet();
      imap.put(interfaze,iset);
    }

    iset.add(clazz);
  }

  private boolean verifyImplements(Class clazz,Class interfaze)
  { return true; }

  private HashMap imap=new HashMap();
  private HashMap map=new HashMap();
  private AdapterFactory factory;
}