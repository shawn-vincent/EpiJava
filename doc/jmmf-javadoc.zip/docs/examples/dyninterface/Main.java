import fr.umlv.jmmf.reflect.*;
import fr.umlv.jmmf.adapter.*;

public class Main {
  interface I {
    void m(I i);
    void n(I i);
  }  

  static class A {   // dynamic implementation of I
    public void m(I i) {
      System.out.println("i: it works !!! :"+i.getClass());
    }
    public void n(A a) {
      System.out.println("a: it works !!! :"+a.getClass());
    }
  }

  public static void test(I i) {
    System.out.println("in test...");
    i.m(i);
    //i.n(i);
  }

  public static void main(String[] args)
    throws Exception
  {
    DynamicMultiMethodFactory factory=new DynamicMultiMethodFactory();
    factory.doImplements(A.class,I.class);

    MultiMethod test=factory.create(Main.class,"test",1);
    test.invoke(null,new Object[]{new A()});
  }
}