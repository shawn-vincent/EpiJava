import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class Main implements EventReceiver {

  /** generic method for receiving a message.
   */
  public void receive(EventObject ev) {
    System.out.println("receive event "+ev);
  }

  /** specialized methods.
   */
  public void receive(AWTEvent ev) {
    System.out.println("receive event "+ev);
    System.out.println("  id "+ev.getID());
  }

  public static void main(String[] args) {
    Main main=new Main();

    EventNotificationService ens=new EventNotificationService();
    ens.addEventReceiver(main);

    ens.send(new EventObject(main));
    ens.send(new TextEvent(main, 0));
  }
}