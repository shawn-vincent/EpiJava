import java.util.*;

/**
 */
public interface EventReceiver {

  /** generic method for receiving an event.
   */
  void receive(EventObject ev);
}