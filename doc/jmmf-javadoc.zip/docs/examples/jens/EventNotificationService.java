import java.util.*;
import java.lang.reflect.*;
import fr.umlv.jmmf.reflect.*;

public class EventNotificationService {

  public void addEventReceiver(EventReceiver r) {
    list.add(r);
  }

  public void removeEventReceiver(EventReceiver r) {
    list.remove(r);
  }

  public void send(EventObject event) {
    Object[] args=new Object[]{event};
    for(Iterator it=list.iterator();it.hasNext();) {
      try {
        mm.invoke(it.next(),args);
      }
      catch(MultipleMethodsException e) {
        System.err.println("multiple possible receivers");
        e.printStackTrace();
      }
      catch(InvocationTargetException e) {
        e.printStackTrace();
      }
      catch(Exception e) {
        e.printStackTrace();
        throw new InternalError();
      }
    }
  }

  ArrayList list=new ArrayList();
  MultiMethod mm=MultiMethod.create(EventReceiver.class,"receive",1);
}