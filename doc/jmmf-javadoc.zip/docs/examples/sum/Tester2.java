import fr.umlv.jmmf.reflect.*;

public class Tester2 implements Testlet
{
  public int sum(Node node)
  { return sum_call(node.getLeft())+sum_call(node.getRight()); }
  public int sum(Leaf leaf)
  { return leaf.getValue(); }

  public int sum_call(Tree tree)
  { 
    try
    {
      Object[] args=new Object[]{tree};
      return ((Integer)mm.invoke(this,args)).intValue(); 
    }
    catch(Exception e)
    { 
      e.printStackTrace();
      throw new Error("internal error ");
    }
  }

  public int test(Tree tree)
  { return sum_call(tree); }

  static MultiMethod mm=MultiMethod.create(Tester2.class,"sum",1);

  public static void main(String[] args) 
    throws Exception
  {
    Tree tree=new NodeImpl(new NodeImpl(new LeafImpl(1),
      new LeafImpl(3)),new LeafImpl(7));
    System.out.println("sum "+new Tester2().sum_call(tree));
  }
}