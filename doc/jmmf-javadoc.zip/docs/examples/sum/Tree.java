// abstract type

interface Tree { }

interface Leaf extends Tree {
  int getValue();
}

interface Node extends Tree {
  Tree getLeft();
  Tree getRight();
}

// implementation

class NodeImpl implements Node {
  public NodeImpl(Tree left,Tree right) {
    this.left=left;
    this.right=right;
  }
  public Tree getLeft() {
    return left;
  }
  public Tree getRight() {
    return right;
  }

  public void setLeft(Tree left) { 
    this.left=left; 
  }
  public void setRight(Tree right) { 
    this.right=right; 
  }
  
  private Tree left,right;
}

class LeafImpl implements Leaf {
  public LeafImpl(int value) {
    this.value=value;
  }
  public int getValue() {
    return value;
  }  

  private int value;
}