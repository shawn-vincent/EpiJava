import java.util.*;
import fr.umlv.jmmf.matcher.*;

public interface Testlet
{
  int test(Tree tree);
}