import java.util.*;
import fr.umlv.jmmf.matcher.*;

public final class Generator
{
  private Generator()
  {
    list.add(new NodeImpl(nextLeaf(),nextLeaf()));
  }

  private Node nextNode()
  {
    int pos=random.nextInt(list.size());
    NodeImpl node=(NodeImpl)list.get(pos);

    NodeImpl n;
    double branch=random.nextDouble();
    if (branch<0.5)
    {
      n=new NodeImpl(node.getLeft(),nextLeaf());
      node.setLeft(n);
    }
    else
    {
      n=new NodeImpl(nextLeaf(),node.getRight());
      node.setRight(n);
    }

    list.add(n);
    return n;
  }

  private Leaf nextLeaf()
  { return new LeafImpl(value++); }

  private Tree getTree()
  { return (Tree)list.get(0); }

  Random random=new Random();
  ArrayList list=new ArrayList();

  static int value;

  public static Tree gener(int number)
  {
    // synchronized(value)
    {
      value=0;
      Generator g=new Generator();
      for(int i=0;i<number;i++)
        g.nextNode();

      return g.getTree();
    }
  }
}