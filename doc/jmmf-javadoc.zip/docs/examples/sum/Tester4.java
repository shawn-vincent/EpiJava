import fr.umlv.jmmf.reflect.*;
import fr.umlv.jmmf.adapter.*;

interface SumTree extends Tree {
  public int sum();
}
interface SumNode extends SumTree { 
  public SumTree getLeft();
  public SumTree getRight();
}
interface SumLeaf extends SumTree,Leaf {
}

public class Tester4 implements Testlet
{
  public Tester4()
  {
    factory=new AdapterFactory();
    factory.addInterface(Node.class,SumNode.class);
    factory.addInterface(Leaf.class,SumLeaf.class);

    MultiMethod mm=MultiMethod.create(Tester4.class,"sum",1);
    factory.addMultiMethod(this,mm,AdapterFactory.SEND_ADAPTER);
  }

  public int sum(SumNode node) { 
    return node.getLeft().sum()+node.getRight().sum(); 
  }
  public int sum(SumLeaf leaf) { 
    return leaf.getValue(); 
  }

  public int test(Tree tree) {
    return ((SumTree)factory.create(tree)).sum();
  }

  AdapterFactory factory;

  public static void main(String[] args) 
    throws Exception
  {
    Tree tree=new NodeImpl(new NodeImpl(new LeafImpl(1),
      new LeafImpl(3)),new LeafImpl(7));

    System.out.println("sum "+new Tester4().test(tree));
  }
}