import java.util.*;
import fr.umlv.jmmf.matcher.*;

public class Test
{
  public static void profile(String clazz,int number,Tree tree)
    throws Exception
  {
    // call garbage collector
    System.gc();

    String name=clazz+Integer.toString(number);
    Testlet t=(Testlet)Class.forName(name).newInstance();
    long millis=System.currentTimeMillis();
    int value=0;
    for(int j=0;j<50;j++)
      value=t.test(tree);
    long millis2=System.currentTimeMillis();
    System.out.println("value "+value+" time(ms) "+(millis2-millis)/50.0);
  }

  public static void main(String[] args) 
    throws Exception
  {
    Tree tree=Generator.gener(1000);
    
    if (args.length>0)
    {
      profile("Tester",Integer.parseInt(args[0]),tree);
    }
    else
    {
      for(int i=0;i<=4;i++)
        profile("Tester",i,tree);
    }
  }
}