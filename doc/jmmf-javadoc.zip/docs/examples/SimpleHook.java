import fr.umlv.jmmf.hook.*;
import fr.umlv.jmmf.adapter.*;

interface M {
  void call(int i);
}

class A implements M {
  public void call(int i) {
    System.out.println("in method m");
  }
}
   
public class SimpleHook extends DefaultAdapterHook {
  public void preHook(AdapterPreMessage m) {
    System.out.print("method "+m.getMultiMethodName()+" of ");
    System.out.println(m.getSource().getAdaptee().getClass());
    Object[] parameters=m.getParameters();
    for(int i=0;i<parameters.length;i++)
      System.out.println(" args["+i+"]="+parameters[i]);
  }
  
  public static void main(String[] args) {
    AdapterFactory factory=new AdapterFactory();
    factory.setKeepAdapteeInterfaces(true);
    factory.setHook(new SimpleHook());
    
    M m=(M)factory.create(new A());
    m.call(3);  
    m.call(125);  
  }
}
