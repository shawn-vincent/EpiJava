public interface Node
{
  public Iterator edges();
}
