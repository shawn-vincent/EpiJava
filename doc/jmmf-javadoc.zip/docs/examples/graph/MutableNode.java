public interface MutableNode extends Node
{
  public void add(Node node);
}
