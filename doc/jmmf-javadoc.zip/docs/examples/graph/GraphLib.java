import java.util.*;

public class GraphLib
{
  public MutableNode createMutableNode(final String name)
  {
    return new MutableNode() {
      public void add(Node node)
      { nodes.add(node); }

      public String toString()
      { return "node ("+name+")"; }

      public Iterator edges()
      { return nodes.iterator(); }

      ArrayList nodes=new ArrayList();
    };
  }
}
