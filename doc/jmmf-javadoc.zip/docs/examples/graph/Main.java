import java.util.*;

public class Main
{
  static Node createGraph(GraphLib lib)
  {
    MutableNode a=lib.createMutableNode("a");
    MutableNode b=lib.createMutableNode("b");
    MutableNode c=lib.createMutableNode("c");
    MutableNode d=lib.createMutableNode("d");

    a.add(b);
    a.add(c);

    b.add(a);
    b.add(d);

    c.add(b);

    return a;
  }

  public static void main(String[] args) {    
    Node graph=createGraph(new GraphLib());

    Map map=new DistanceAlgo().process(graph);
    for(Iterator it=map.entrySet().iterator();it.hasNext();)
    {
      Map.Entry entry=(Map.Entry)it.next();
      System.out.println(entry.getKey()+"="+entry.getValue());
    }
  }
}
