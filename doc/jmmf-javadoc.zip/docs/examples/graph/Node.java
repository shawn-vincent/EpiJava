import java.util.*;

public interface Node
{
  public Iterator edges();
}
