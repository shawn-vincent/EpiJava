import java.util.*;
import fr.umlv.jmmf.adapter.*;
import fr.umlv.jmmf.reflect.*;

public class DistanceAlgo
{
  interface NodeIterator {
    boolean hasNext();
    DistanceNode next();
  }

  interface DistanceNode {
    int getDistance();
    void setDistance(int d);

    void processDistance(int delta);

    NodeIterator edges();
  }

  public Map process(Node node)
  {
    AdapterFactory factory=new AdapterFactory();
    factory.addInterface(Node.class,DistanceNode.class);
    factory.addInterface(Iterator.class,NodeIterator.class);

    factory.setAdapterUnicity(true);

    // add field distance
    HashMap map=new HashMap();
    factory.addField("distance",new Integer(Integer.MAX_VALUE),map);

    // add processDistance method
    factory.addMultiMethod(this,mm,AdapterFactory.SEND_ADAPTER);

    // adapt and call
    DistanceNode dNode=(DistanceNode)factory.create(node);
    ((DistanceNode)dNode).processDistance(0);

    return map;
  }

  private void processDistance(DistanceNode node,int delta)
  {
    int d=node.getDistance();

    // System.out.println("process "+node+" "+d+" delta "+delta);
    node.setDistance(Math.min(d,delta));

    if (d==Integer.MAX_VALUE)
    {
      for(NodeIterator it=node.edges();it.hasNext();)
        it.next().processDistance(delta+1);
    }
  }

  MultiMethod mm=MultiMethod.create(getClass(),"processDistance",2);
}
