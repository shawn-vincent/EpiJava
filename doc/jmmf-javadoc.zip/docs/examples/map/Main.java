import java.util.*;
import fr.umlv.jmmf.adapter.*;
import fr.umlv.jmmf.reflect.*;

public class Main
{
  interface KeyIterator {
    String next();
    boolean hasNext();
  }

  interface IdMap {
    void put(String key,int id);
    int get(String key);

    KeyIterator keys();    
  }

  public static Iterator keys(Map map)
  { return map.keySet().iterator(); }

  public static void main(String[] args) {
    AdapterFactory factory=new AdapterFactory();
    factory.addInterface(Map.class,IdMap.class);
    factory.addInterface(Iterator.class,KeyIterator.class);

    MultiMethod mm=MultiMethod.create(Main.class,"keys",1);
    factory.addMultiMethod(null,mm,AdapterFactory.SEND_ADAPTEE);

    IdMap map=(IdMap)factory.create(new HashMap());

    map.put("toto",24);
    map.put("titi",32);
    System.out.println(2*map.get("toto"));

    for(KeyIterator it=map.keys();it.hasNext();)
      System.out.println(it.next().substring(1));
  }
}