public interface Expr {
  public interface Variable extends Expr {
    String getName();
  }

  public interface Value extends Expr {
    int getValue();
  }

  public interface Op extends Expr {
    Expr getLeft();
    Expr getRight();
  }

  public interface Plus extends Op {
  }

  public interface Minus extends Op {
  }  
}