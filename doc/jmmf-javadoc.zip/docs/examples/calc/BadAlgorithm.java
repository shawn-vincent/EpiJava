public class BadAlgorithm extends Algorithm
{
  public String toString(Expr expr)
  { 
    if (expr instanceof Expr.Plus)
      return ((Algorithm)this).toString((Expr.Plus)expr);
    else
      if (expr instanceof Expr.Minus)
        return ((Algorithm)this).toString((Expr.Minus)expr);
      else
        if (expr instanceof Expr.Variable)
          return ((Algorithm)this).toString((Expr.Variable)expr);
        else
          if (expr instanceof Expr.Value)
            return ((Algorithm)this).toString((Expr.Value)expr);
          else
            throw new Error("internal error");
  }   
}