public abstract class Algorithm
{
  protected String toString(Expr.Plus p)
  { return toString(p.getLeft())+"+"+toString(p.getRight()); }

  protected String toString(Expr.Minus m)
  { return toString(m.getLeft())+"-"+toString(m.getRight()); }

  protected String toString(Expr.Value v)
  { return ""+v.getValue(); }
 
  protected String toString(Expr.Variable v)
  { return v.getName(); }

  public abstract String toString(Expr expr);
}