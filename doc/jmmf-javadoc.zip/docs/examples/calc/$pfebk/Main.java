public class Main
{
  public static String toString(Algorithm a,Expr expr)
  {
    String s=null;
  
    System.gc();
    long time=System.currentTimeMillis();
    for(int j=0;j<500;j++)
      s=a.toString(expr);
    long time2=System.currentTimeMillis();
    System.out.println("delta time "+(time2-time)/500.0);
    return s;
  } 

  public static Expr gener(int value)
  {
    Expr expr=Impl.variable("a");
    for(int i=0;i<value;i++)
    {
      if (i%2==0)
        if (i%3!=0)
          expr=Impl.plus(Impl.value(i),expr);
        else
          expr=Impl.plus(Impl.variable("b"),expr);
      else
        if (i%3!=0)
          expr=Impl.minus(Impl.value(i),expr);
        else
          expr=Impl.minus(Impl.variable("a"),expr);
    }
    return expr;
  }

  public static void main(String[] args)
  {
    Expr expr=gener(200);

    long time=System.currentTimeMillis();
    GoodAlgorithm ga=new GoodAlgorithm();
    long time2=System.currentTimeMillis();
    System.out.println("load time "+(time2-time));

    System.out.println(toString(ga,expr));
    System.out.println(toString(new BadAlgorithm(),expr));
  }
}