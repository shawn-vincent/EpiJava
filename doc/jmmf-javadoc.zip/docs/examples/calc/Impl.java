public class Impl {
  public static Expr.Value value(final int value) {
    return new Expr.Value() {
      public int getValue() {
        return value;
      }
    };
  }

  public static Expr.Variable variable(final String name) {
    return new Expr.Variable() {
      public String getName() {
        return name;
      }
    };
  }

  public static Expr.Plus plus(final Expr left,final Expr right) {
    return new Expr.Plus() {
      public Expr getLeft() {
        return left;
      }
      public Expr getRight() {
        return right;
      }
    };
  }

  public static Expr.Minus minus(final Expr left,final Expr right) {
    return new Expr.Minus() {
      public Expr getLeft() {
        return left;
      }
      public Expr getRight() {
        return right;
      }
    };
  }
}