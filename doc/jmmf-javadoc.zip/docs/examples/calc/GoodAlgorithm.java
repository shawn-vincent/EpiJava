import fr.umlv.jmmf.reflect.*;

public class GoodAlgorithm extends Algorithm
{
  public String toString(Expr expr)
  { 
    try
    { return (String)mmToString.invoke(this,new Object[]{expr}); }
    catch(Exception e)
    {
      e.printStackTrace();
      throw new Error("internal error");
    }
  }
  
  final static MultiMethod mmToString=
    MultiMethod.create(GoodAlgorithm.class,"toString",1);
}