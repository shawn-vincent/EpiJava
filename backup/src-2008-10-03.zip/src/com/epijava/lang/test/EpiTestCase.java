/*
 * 
 */
package com.epijava.lang.test;

/**
 * Base class for EpiJava test cases
 *
 */
public class EpiTestCase {
}
