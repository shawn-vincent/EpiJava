/*
 * 
 */
package com.epijava.lang.type;


/**
 * The EpiJava TypeChecker
 * 
 */
public class TypeChecker {


}
