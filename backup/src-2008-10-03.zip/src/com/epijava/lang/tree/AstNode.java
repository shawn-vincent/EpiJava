/*
 * 
 */
package com.epijava.lang.tree;

/**
 * 
 *
 */
public @interface AstNode {
}
