/*
 *
 *
 */
package com.epijava.lang.tree;


/**
 * A visitor over Java expression nodes.
 **/
public class EpiVisitor<P,R> {

    // XXX not used: we use Multimethod instead to eliminate the boilerplate.
    
    // XXX in the future, we may want to use real visitors for performance reasons, but for now, this aids implementation speed considerably.

}