/*
 * 
 */
package com.epijava.lang.tree;

import com.epijava.lang.type.*;
import com.epijava.util.*;

/**
 * 
 *
 */
public abstract class TypeReference extends Reference<Type> {

    /**
     * 
     */
    public TypeReference(Locus _locus) {
        super(_locus);
    }

}
