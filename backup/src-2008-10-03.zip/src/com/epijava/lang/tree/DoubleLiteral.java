/*
 * 
 */
package com.epijava.lang.tree;

import com.epijava.util.*;

/**
 * 
 *
 */
public class DoubleLiteral extends NumberLiteral<Double> {

    public DoubleLiteral(Locus _locus, Double _value) {
        super(_locus, _value);
    }

}