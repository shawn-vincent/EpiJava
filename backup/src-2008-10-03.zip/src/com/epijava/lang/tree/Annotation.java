/*
 *
 */
package com.epijava.lang.tree;

import com.epijava.util.*;

/**
 * 
 *
 */
public class Annotation extends Expression {

    public Annotation(Locus _locus) {
        super(_locus);
    }

}
