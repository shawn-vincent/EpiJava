/*
 * 
 */
package com.epijava.lang.parser.util;

/**
 * 
 *
 */
public abstract class Parser {

}
