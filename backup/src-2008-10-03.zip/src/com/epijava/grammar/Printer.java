/*
 * 
 */
package com.epijava.grammar;

/**
 * 
 * 
 */
public class Printer {

    public String printToString(final Object expr) {
        throw new UnsupportedOperationException();
    }

    public Printer setPrintRules(final PrintRules rules) {
        throw new UnsupportedOperationException();
    }

}
