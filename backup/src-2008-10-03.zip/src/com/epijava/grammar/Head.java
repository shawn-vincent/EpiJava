package com.epijava.grammar;

import java.util.*;

public class Head {

    public final Grammar rule;
    public Set<Grammar> involvedSet = new HashSet<Grammar>();
    public Set<Grammar> evalSet = new HashSet<Grammar>();
    
    public Head(Grammar _rule) { rule = _rule; }

}
