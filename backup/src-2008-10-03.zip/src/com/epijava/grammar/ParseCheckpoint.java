/*
 * 
 */
package com.epijava.grammar;

/**
 * 
 *
 */
public interface ParseCheckpoint {
}
