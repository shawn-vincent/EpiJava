///*
// * 
// */
//package com.epijava.grammar;
//
///**
// * 
// *
// */
//public class UnexpectedTokenError extends ParseError {
//    
//
//    private final String wantedStr;
//    private final String gotStr;
//    
//    private final Object wanted;
//    private final Object got;
//
//    public UnexpectedTokenError(ParserState<?> parse, Object _wanted, String _wantedStr, Object _got, String _gotStr) {
//        super(parse);
//        wanted = _wanted;
//        wantedStr = _wantedStr;
//        got = _got;
//        gotStr = _gotStr;
//    }
//
//
//    public String getWantedStr() {
//        return wantedStr;
//    }
//
//    public String getGotStr() {
//        return gotStr;
//    }
//    
//    public String getMessage() {
//        return "expected "+wantedStr+", got "+gotStr;
//    }
//
//
//    public Object getWanted() {
//        return wanted;
//    }
//
//
//    public Object getGot() {
//        return got;
//    }
//
//
//}
