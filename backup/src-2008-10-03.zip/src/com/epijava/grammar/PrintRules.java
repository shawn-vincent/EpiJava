/*
 * 
 */
package com.epijava.grammar;

/**
 * 
 *
 */
public class PrintRules {

    
   
    public static Rule newline() {
        throw new UnsupportedOperationException();
    }
    
    public static class Rule {

        public Rule indent(final int i) {
            throw new UnsupportedOperationException();
        }

    }

    public PrintRules rule(final String string, final Rule indent) {
        throw new UnsupportedOperationException();
    }

}
